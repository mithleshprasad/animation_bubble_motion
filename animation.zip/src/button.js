// import React, { useState, useEffect } from "react";
// import "./style.css";

// const BubbleContainer = () => {
//   const [bubbles, setBubbles] = useState([]);
//   const names = [
//     "DevOps",
//     "Data Scientist",
//     "Developer",
//     "UI/UX",
//     "Designer",
//     "Frontend Developer",
//     "Backend Developer",
//     "Product Manager",
//     "Quality Assurance",
//     "System Administrator"
//   ];

//   const colors = [
//     "red",
//     "blue",
//     "green",
//     "orange",
//     "purple",
//     "yellow",
//     "pink",
//     "cyan",
//     "magenta",
//     "teal"
//   ];

//   const createBubbles = () => {
//     const bubbleCount = 10;
//     const newBubbles = [];
//     const containerHeight = window.innerHeight;
//     for (let i = 0; i < bubbleCount; i++) {
//       const bubble = {
//         id: i,
//         name: names[i % names.length], // Use static names from the names array
//         color: colors[i % colors.length],
//         x: Math.random() * (window.innerWidth - 140) + "px",
//         y: containerHeight - 50 + "px", // Position all bubbles at the bottom of the container
//       };
//       newBubbles.push(bubble);
//     }
//     setBubbles(newBubbles);
//   };

//   const handleBubbleHover = (index) => {
//     const updatedBubbles = bubbles.map((bubble, i) => {
//       if (i === index) {
//         const slowFactor = 5; // Adjust the slow factor as needed
//         const newX = Math.random() * (window.innerWidth - 140);
//         const newY = Math.random() * (window.innerHeight - 50);
//         const deltaX = (newX - parseFloat(bubble.x)) / slowFactor;
//         const deltaY = (newY - parseFloat(bubble.y)) / slowFactor;
//         return {
//           ...bubble,
//           targetX: newX,
//           targetY: newY,
//           deltaX,
//           deltaY,
//         };
//       }
//       return bubble;
//     });
//     setBubbles(updatedBubbles);
//   };

//   useEffect(() => {
//     const updateBubblePositions = () => {
//       setBubbles((prevBubbles) => {
//         return prevBubbles.map((bubble) => {
//           if (bubble.targetX !== undefined && bubble.targetY !== undefined) {
//             const dx = bubble.targetX - parseFloat(bubble.x);
//             const dy = bubble.targetY - parseFloat(bubble.y);
//             if (Math.abs(dx) < 1 && Math.abs(dy) < 1) {
//               // If the bubble is close to the target, stop moving
//               return {
//                 ...bubble,
//                 x: bubble.targetX + "px",
//                 y: bubble.targetY + "px",
//                 targetX: undefined,
//                 targetY: undefined,
//               };
//             } else {
//               // Move the bubble towards the target
//               return {
//                 ...bubble,
//                 x: parseFloat(bubble.x) + bubble.deltaX + "px",
//                 y: parseFloat(bubble.y) + bubble.deltaY + "px",
//               };
//             }
//           }
//           return bubble;
//         });
//       });
//       requestAnimationFrame(updateBubblePositions);
//     };

//     requestAnimationFrame(updateBubblePositions);

//     return () => cancelAnimationFrame(updateBubblePositions);
//   }, [bubbles]);

//   return (
//     <div className="">
//       <div className="bubble-container bg-dark" onMouseEnter={createBubbles}>
//         {bubbles.map((bubble, index) => (
//           <div
//             key={bubble.id}
//             className="bubble"
//             style={{
//               top: bubble.y,
//               left: bubble.x,
//               backgroundColor: bubble.color,
//             }} // Set the background color dynamically
//             onMouseEnter={() => handleBubbleHover(index)}
//           >
//             {bubble.name}
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default BubbleContainer;
// import React, { useState, useEffect } from "react";
// import "./style.css";

// const BubbleContainer = () => {
//   const [bubbles, setBubbles] = useState([]);
//   const names = [
//     "DevOps",
//     "Data Scientist",
//     "Developer",
//     "UI/UX",
//     "Designer",
//     "Frontend Developer",
//     "Backend Developer",
//     "Product Manager",
//     "Quality Assurance",
//     "System Administrator"
//   ];

//   const colors = [
//     "red",
//     "blue",
//     "green",
//     "orange",
//     "purple",
//     "yellow",
//     "pink",
//     "cyan",
//     "magenta",
//     "teal"
//   ];

//   const createBubbles = () => {
//     const bubbleCount = 10;
//     const newBubbles = [];
//     const containerHeight = window.innerHeight;
//     for (let i = 0; i < bubbleCount; i++) {
//       const bubble = {
//         id: i,
//         name: names[i % names.length],
//         color: colors[i % colors.length],
//         x: Math.random() * (window.innerWidth - 140) + "px",
//         y: 0,
//         speed: Math.random() * 3 + 1 // Random speed between 1 and 4
//       };
//       newBubbles.push(bubble);
//     }
//     setBubbles(newBubbles);
//   };

//   const moveBubbles = () => {
//     setBubbles(prevBubbles => {
//       return prevBubbles.map(bubble => ({
//         ...bubble,
//         y: bubble.y + bubble.speed
//       }));
//     });
//   };

//   useEffect(() => {
//     createBubbles();
//   }, []);

//   useEffect(() => {
//     const interval = setInterval(moveBubbles, 50); // Adjust the interval as needed
//     return () => clearInterval(interval);
//   }, []);

//   const handleBubbleHover = (index) => {
//     setBubbles(prevBubbles => {
//       return prevBubbles.map((bubble, i) => {
//         if (i === index) {
//           const newX = Math.random() * (window.innerWidth - 140) + "px";
//           const newY = Math.random() * (window.innerHeight - 50) + "px";
//           return {
//             ...bubble,
//             targetX: newX,
//             targetY: newY,
//             deltaX: (newX - parseFloat(bubble.x)) / 10,
//             deltaY: (newY - parseFloat(bubble.y)) / 10
//           };
//         }
//         return bubble;
//       });
//     });
//   };

//   const handleBubbleClick = (index) => {
//     setBubbles(prevBubbles => {
//       return prevBubbles.map((bubble, i) => {
//         if (i === index) {
//           const newX = Math.random() * (window.innerWidth - 140) + "px";
//           const newY = Math.random() * (window.innerHeight - 50) + "px";
//           return {
//             ...bubble,
//             targetX: newX,
//             targetY: newY,
//             deltaX: (newX - parseFloat(bubble.x)) / 10,
//             deltaY: (newY - parseFloat(bubble.y)) / 10
//           };
//         }
//         return bubble;
//       });
//     });
//   };

//   return (
//     <div className="">
//       <div className="bubble-container bg-dark">
//         {bubbles.map((bubble, index) => (
//           <div
//             key={bubble.id}
//             className="bubble"
//             style={{
//               top: bubble.y + "px",
//               left: bubble.x,
//               backgroundColor: bubble.color,
//             }}
//             onMouseEnter={() => handleBubbleHover(index)}
//             onClick={() => handleBubbleClick(index)}
//           >
//             {bubble.name}
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default BubbleContainer;
// import React, { useState, useEffect } from "react";
// import "./style.css";

// const BubbleContainer = () => {
//   const [bubbles, setBubbles] = useState([]);
//   const names = [
//     "DevOps",
//     "Data Scientist",
//     "Developer",
//     "UI/UX",
//     "Designer",
//     "Frontend Developer",
//     "Backend Developer",
//     "Product Manager",
//     "Quality Assurance",
//     "System Administrator",
//   ];

//   const colors = [
//     "red",
//     "blue",
//     "green",
//     "orange",
//     "purple",
//     "yellow",
//     "pink",
//     "cyan",
//     "magenta",
//     "teal",
//   ];

//   const createBubbles = () => {
//     const bubbleCount = 10;
//     const newBubbles = [];
//     for (let i = 0; i < bubbleCount; i++) {
//       const bubble = {
//         id: i,
//         name: names[i % names.length],
//         color: colors[i % colors.length],
//         x: Math.random() * (window.innerWidth - 140) + "px",
//         y: 0,
//         speed: Math.random() * 3 + 1, // Random speed between 1 and 4
//       };
//       newBubbles.push(bubble);
//     }
//     setBubbles(newBubbles);
//   };

//   const moveBubbles = () => {
//     setBubbles((prevBubbles) => {
//       return prevBubbles.map((bubble) => {
//         const newY = bubble.y + bubble.speed;
//         if (newY >= window.innerHeight - 50) {
//           // If the bubble reaches the bottom, stop its movement
//           return {
//             ...bubble,
//             y: window.innerHeight - 50,
//           };
//         } else {
//           return {
//             ...bubble,
//             y: newY,
//           };
//         }
//       });
//     });
//   };

//   useEffect(() => {
//     createBubbles();
//   }, []);

//   useEffect(() => {
//     const interval = setInterval(moveBubbles, 50); // Adjust the interval as needed
//     return () => clearInterval(interval);
//   }, []);

//   const handleBubbleHover = (index) => {
//     setBubbles((prevBubbles) => {
//       return prevBubbles.map((bubble, i) => {
//         if (i === index) {
//           const newX = Math.random() * (window.innerWidth - 140) + "px";
//           const newY = Math.random() * (window.innerHeight - 50) + "px";
//           return {
//             ...bubble,
//             targetX: newX,
//             targetY: newY,
//             deltaX: (newX - parseFloat(bubble.x)) / 10,
//             deltaY: (newY - parseFloat(bubble.y)) / 10,
//           };
//         }
//         return bubble;
//       });
//     });
//   };

//   const handleBubbleClick = (index) => {
//     setBubbles((prevBubbles) => {
//       return prevBubbles.map((bubble, i) => {
//         if (i === index) {
//           const newX = Math.random() * (window.innerWidth - 140) + "px";
//           const newY = Math.random() * (window.innerHeight - 50) + "px";
//           return {
//             ...bubble,
//             targetX: newX,
//             targetY: newY,
//             deltaX: (newX - parseFloat(bubble.x)) / 10,
//             deltaY: (newY - parseFloat(bubble.y)) / 10,
//           };
//         }
//         return bubble;
//       });
//     });
//   };

//   return (
//     <div className="">
//       <div className="bubble-container bg-dark">
//         {bubbles.map((bubble, index) => (
//           <div
//             key={bubble.id}
//             className="bubble rounded"
//             style={{
//               top: bubble.y + "px",
//               left: bubble.x,
//               backgroundColor: bubble.color,
//             }}
//             onMouseEnter={() => handleBubbleHover(index)}
//             onClick={() => handleBubbleClick(index)}
//           >
//             {bubble.name}
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default BubbleContainer;
// import React, { useState, useEffect } from "react";
// import "./style.css";

// const BubbleContainer = () => {
//   const [bubbles, setBubbles] = useState([]);
//   const names = [
//     "DevOps",
//     "Data Scientist",
//     "Developer",
//     "UI/UX",
//     "Designer",
//     "Frontend Developer",
//     "Backend Developer",
//     "Product Manager",
//     "Quality Assurance",
//     "System Administrator",
//   ];

//   const colors = [
//     "red",
//     "blue",
//     "green",
//     "orange",
//     "purple",
//     "yellow",
//     "pink",
//     "cyan",
//     "magenta",
//     "teal",
//   ];

//   const createBubbles = () => {
//     const bubbleCount = 10;
//     const newBubbles = [];
//     for (let i = 0; i < bubbleCount; i++) {
//       const bubble = {
//         id: i,
//         name: names[i % names.length],
//         color: colors[i % colors.length],
//         x: Math.random() * (window.innerWidth - 140) + "px",
//         y: 0,
//         speed: Math.random() * 3 + 1, // Random speed between 1 and 4
//       };
//       newBubbles.push(bubble);
//     }
//     setBubbles(newBubbles);
//   };

//   const moveBubbles = () => {
//     setBubbles((prevBubbles) => {
//       return prevBubbles.map((bubble) => {
//         const newY = bubble.y + bubble.speed;
//         if (newY >= window.innerHeight - 50) {
//           // If the bubble reaches the bottom, stop its movement
//           return {
//             ...bubble,
//             y: window.innerHeight - 50,
//           };
//         } else {
//           return {
//             ...bubble,
//             y: newY,
//           };
//         }
//       });
//     });
//   };

//   useEffect(() => {
//     createBubbles();
//   }, []);

//   useEffect(() => {
//     const interval = setInterval(moveBubbles, 50); // Adjust the interval as needed
//     return () => clearInterval(interval);
//   }, []);

//   const handleContainerMouseMove = (event) => {
//     const containerRect = event.target.getBoundingClientRect();
//     const mouseX = event.clientX - containerRect.left;
//     const mouseY = event.clientY - containerRect.top;

//     setBubbles((prevBubbles) => {
//       return prevBubbles.map((bubble) => {
//         const distanceX = mouseX - parseFloat(bubble.x);
//         const distanceY = mouseY - parseFloat(bubble.y);
//         const distance = Math.sqrt(distanceX ** 2 + distanceY ** 2);
//         const speed = 5; // Adjust speed as needed
//         const ratio = speed / distance;

//         return {
//           ...bubble,
//           x: parseFloat(bubble.x) + distanceX * ratio,
//           y: parseFloat(bubble.y) + distanceY * ratio,
//         };
//       });
//     });
//   };

//   return (
//     <div
//       className="bubble-container bg-dark"
//       onMouseMove={handleContainerMouseMove}
//     >
//       {bubbles.map((bubble) => (
//         <div
//           key={bubble.id}
//           className="bubble rounded"
//           style={{
//             top: bubble.y + "px",
//             left: bubble.x,
//             backgroundColor: bubble.color,
//           }}
//         >
//           {bubble.name}
//         </div>
//       ))}
//     </div>
//   );
// };

// export default BubbleContainer;
import React, { useState, useEffect } from "react";
import "./style.css";

const BubbleContainer = () => {
  const [bubbles, setBubbles] = useState([]);
  const names = [
    "DevOps",
    "Data Scientist",
    "Developer",
    "UI/UX",
    "Designer",
    "Frontend Developer",
    "Backend Developer",
    "Product Manager",
    "Quality Assurance",
    "System ",
    "Network Engineer",
    "Database ",
    "Security Analyst",
    "Cloud Architect",
    "AI Engineer",
    "Game Developer",
    "Mobile Developer",
    "Embedded Engineer",
    "DevOps Engineer",
    "Blockchain Developer",
  ];

  const colors = [
    "#ff5733",
    "#33ff57",
    "#5733ff",
    "#ff3399",
    "#33ffff",
    "#ffff33",
    "#ff33ff",
    "#33ff99",
    "#ff99cc",
    "#9966ff",
    "#ff6633",
    "#33ff66",
    "#ffcc33",
    "#3366ff",
    "#ff9966",
    "#33ccff",
    "#ff6633",
    "#ff9933",
    "#ff33cc",
    "#33cc99",
  ];

  const createBubbles = () => {
    const bubbleCount = 20;
    const newBubbles = [];
    for (let i = 0; i < bubbleCount; i++) {
      const bubble = {
        id: i,
        name: names[i % names.length],
        color: colors[i % colors.length],
        x: Math.random() * (window.innerWidth - 140) + "px",
        y: 0,
        speed: Math.random() * 3 + 1, 
      };
      newBubbles.push(bubble);
    }
    setBubbles(newBubbles);
  };

  const moveBubbles = () => {
    setBubbles((prevBubbles) => {
      return prevBubbles.map((bubble) => {
        const newY = bubble.y + bubble.speed;
        if (newY >= window.innerHeight - 50) {
         
          return {
            ...bubble,
            y: window.innerHeight - 50,
          };
        } else {
          return {
            ...bubble,
            y: newY,
          };
        }
      });
    });
  };

  useEffect(() => {
    createBubbles();
  }, []);

  useEffect(() => {
    const interval = setInterval(moveBubbles, 50); 
    return () => clearInterval(interval);
  }, []);

  const handleContainerMouseMove = (event) => {
    const containerRect = event.target.getBoundingClientRect();
    const mouseX = event.clientX - containerRect.left;
    const mouseY = event.clientY - containerRect.top;

    setBubbles((prevBubbles) => {
      return prevBubbles.map((bubble) => {
        const distanceX = mouseX - parseFloat(bubble.x);
        const distanceY = mouseY - parseFloat(bubble.y);
        const distance = Math.sqrt(distanceX ** 2 + distanceY ** 2);
        const speed = bubble.speed;
        const ratio = speed / distance;

        return {
          ...bubble,
          x: parseFloat(bubble.x) + distanceX * ratio,
          y: parseFloat(bubble.y) + distanceY * ratio,
        };
      });
    });
  };

  return (
    <div class="card">
    <h5 class="card-header">Featured</h5>
    <div class="card-body">
    <h3 class="card-text warning">With supporting text below as a natural lead-in to additional content.</h3>

    <div
      className="bubble-container bg-dark"
      onMouseMove={handleContainerMouseMove}
    >
      {bubbles.map((bubble) => (
        <div
          key={bubble.id}
          className="bubble rounded"
          style={{
            top: bubble.y + "px",
            left: bubble.x,
            backgroundColor: bubble.color,
          }}
        >
          {bubble.name}
        </div>
      ))}
    </div>

      <h5 class="card-title">Special title treatment</h5>
      <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
  </div>
    
  );
};

export default BubbleContainer;
