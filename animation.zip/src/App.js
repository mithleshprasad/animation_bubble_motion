import React from "react";
import BubbleContainer from "./button";
import  "./App.css"
const App = () => {
  return (
  
    <div className="container ">
      <BubbleContainer />
    </div>
   
  
  );
};

export default App;
